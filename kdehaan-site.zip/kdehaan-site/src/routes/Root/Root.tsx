

const Root = () => {

  return (
    <h1>Hello, world</h1>
  );

}


export default Root